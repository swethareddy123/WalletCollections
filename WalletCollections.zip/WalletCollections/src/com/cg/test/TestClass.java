package com.cg.test;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.dto.Customer;
import com.cg.dto.Wallet;
import com.cg.exception.InsufficientBalanceException;
import com.cg.exception.InvalidInputException;
import com.cg.service.WalletService;
import com.cg.service.WalletServiceImpl;

public class TestClass {

	static WalletService service;
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {}

	@Before
	public void setUp() throws Exception 
	{
		Map<String,Customer> data= new HashMap<String, Customer>();
		Customer cust1=new Customer("Swetha", "8179323885",new Wallet(new BigDecimal(9000)));
		Customer cust2=new Customer("Hyndhavi", "9177977123",new Wallet(new BigDecimal(6000)));
		Customer cust3=new Customer("Amit", "9163264015",new Wallet(new BigDecimal(7000)));

		data.put("8179323885", cust1);
		data.put("9177977123", cust2);	
		data.put("9163264015", cust3);	
		service= new WalletServiceImpl(data);
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test(expected=InvalidInputException.class)
	public void testCreateAccount1() 
	{
		service.createAccount(null, "8179323885", new BigDecimal(1500));
	}


	@Test(expected=InvalidInputException.class)
	public void testCreateAccount2() 
	{
		service.createAccount("", "8179323885", new BigDecimal(1500));
	}


	@Test(expected=InvalidInputException.class)
	public void testCreateAccount3() 
	{
		service.createAccount("psr", "1234", new BigDecimal(1500));
	}


	@Test(expected=InvalidInputException.class)
	public void testCreateAccount4() 
	{
		service.createAccount("psr", "", new BigDecimal(1500));
	}


	@Test(expected=InvalidInputException.class)
	public void testCreateAccount5() 
	{
		service.createAccount("", "", new BigDecimal(1500));
	}


	@Test(expected=InvalidInputException.class)
	public void testCreateAccount6() 
	{
		service.createAccount("Swetha", "8179323885", new BigDecimal(9000));
	}


	@Test(expected=InvalidInputException.class)
	public void testCreateAccount7() 
	{
		service.createAccount("Swetha", "8179323885", new BigDecimal(-100));
	}

	@Test
	public void testCreateAccount10() 
	{
		Customer actual=service.createAccount("Supriya", "7702725233", new BigDecimal(5000.75));
		Customer expected=new Customer("Supriya", "7702725233", new Wallet(new BigDecimal(5000.75)));

		assertEquals(expected, actual);
	}



	@Test(expected=InvalidInputException.class)
	public void testShowBalance11() 
	{
		service.showBalance(null);		
	}


	@Test(expected=InvalidInputException.class)
	public void testShowBalance12() 
	{
		service.showBalance("");		
	}


	@Test(expected=InvalidInputException.class)
	public void testShowBalance13() 
	{
		service.showBalance("12345");		
	}





	@Test(expected=InvalidInputException.class)
	public void testShowBalance14() 
	{
		service.showBalance("9949037885");		
	}


	@Test
	public void testShowBalance15() 
	{
		Customer customer=service.showBalance("9949037885");
		BigDecimal expectedResult=new BigDecimal(9000);
		BigDecimal obtainedResult=customer.getWallet().getBalance();

		assertEquals(expectedResult, obtainedResult);

	}


	@Test(expected=InvalidInputException.class)
	public void testFundTransfer16() 
	{
		service.fundTransfer("8179323885", "9177977123", new BigDecimal(5000));		
	}



	@Test(expected=InvalidInputException.class)
	public void testFundTransfer17() 
	{
		service.fundTransfer("9177977123", "7702725233", new BigDecimal(5000));		
	}



	@Test(expected=InvalidInputException.class)
	public void testFundTransfer19() 
	{
		service.fundTransfer("9900112212", "9177977123", new BigDecimal(0));		
	}


	@Test(expected=InvalidInputException.class)
	public void testFundTransfer20() 
	{
		service.fundTransfer("8179323885", "", new BigDecimal(0));		
	}


	@Test(expected=InvalidInputException.class)
	public void testFundTransfer21() 
	{
		service.fundTransfer("", "8179323885", new BigDecimal(500));		
	}


	@Test
	public void testFundTransfer22() 
	{
		Customer customer=service.fundTransfer("8179323885", "9177977123", new BigDecimal(500));
		BigDecimal expected=customer.getWallet().getBalance();
		BigDecimal actual=new BigDecimal(8500);

		assertEquals(expected, actual);
	}

}
