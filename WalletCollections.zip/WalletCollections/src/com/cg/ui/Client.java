package com.cg.ui;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import com.cg.dto.*;
import com.cg.exception.InsufficientBalanceException;
import com.cg.exception.InvalidInputException;
import com.cg.service.WalletService;
import com.cg.service.WalletServiceImpl;

public class Client {
	private WalletService walletService;
	private Map<String,Customer> data=new HashMap<String, Customer>();
	public Client() 
	{
		System.out.println("Welcome to Payment Wallet Application");
		walletService=new WalletServiceImpl(data);
	}
	public void Operations()
	{
		System.out.println("1) Create New Paytm Account");
		System.out.println("2) Check Your Balance");
		System.out.println("3) Transfer Funds");
		System.out.println("4) Deposit Amount");
		System.out.println("5) Withdraw Amount");
		System.out.println("6) Exit Application");
		System.out.println("Enter Your Choice");
		Scanner sc=new Scanner(System.in);
		String mobileNo;
		String mobileNo1;
		BigDecimal amount;
		String name;
		Customer customer;
		switch (sc.nextInt()) 
		{
		case 1: 
			do{
				System.out.print("Enter ur name: ");
				name = sc.next();
				try {
					if(walletService.isValidName(name))
						break;
				} catch (Exception e) {
					// TODO Auto-generated catch block
					System.err.println(e.getMessage());
				}
			}while(true);
			do{
				System.out.print("Enter ur mobileNumber: ");
				mobileNo = sc.next();
				try {
					if(walletService.isValidMobile(mobileNo))
						break;
				} catch (Exception e) {
					// TODO Auto-generated catch block
					System.err.println(e.getMessage());
				}
			}while(true);
			do{
				System.out.print("Enter Balance            : ");
				amount=sc.nextBigDecimal();
				try {
					if(walletService.isValidAmount(amount))
						break;
				} catch (Exception e) {
					// TODO Auto-generated catch block
					System.err.println(e.getMessage());
				}
			}while(!true);
			try {
				Customer customer1=walletService.createAccount(name, mobileNo, amount);
				System.out.println("Thank you, "+customer1.getName()+" Your Payment wallet account has been created successfully with Balance "+amount);
			}
			catch (InvalidInputException e)
			{
				System.out.println(e.getMessage());
			}

			break;
		case 2: 
			System.out.print("Enter the Mobile Number : ");
			mobileNo=sc.next();

			try 
			{
				customer=walletService.showBalance(mobileNo);
				System.out.println("Your Current Balance is "+customer.getWallet().getBalance());
			} 
			catch (InvalidInputException | InsufficientBalanceException e)
			{
				System.out.println(e.getMessage());				
			}
			break;
		case 3: 
			System.out.print("Enter the Source Mobile Number : ");
			mobileNo=sc.next();

			System.out.print("Enter the Destination mobile number : ");
			mobileNo1=sc.next();

			System.out.print("Enter the amount  : ");
			amount=sc.nextBigDecimal();
			try 
			{
				customer=walletService.fundTransfer(mobileNo, mobileNo1, amount);
				System.out.println("Your transaction is successfully done.. ");
				System.out.println("Now Your Account Balance is "+customer.getWallet().getBalance());
			} 
			catch (InvalidInputException | InsufficientBalanceException e)
			{
				System.out.println(e.getMessage());				
			}
			break;
		case 4: 
			System.out.print("Enter the Mobile Number : ");
			mobileNo=sc.next();
			System.out.print("Enter the amount to be deposited : ");
			amount=sc.nextBigDecimal();
			try 
			{
				customer=walletService.depositAmount(mobileNo, amount);
				System.out.println("Your have successfully deposited... ");
				System.out.println("Now Your Account Balance is "+customer.getWallet().getBalance());
			} 
			catch (InvalidInputException | InsufficientBalanceException e)
			{
				System.out.println(e.getMessage());				
			}
			break;
		case 5: 

			System.out.print("Enter the Mobile Number : ");
			mobileNo=sc.next();

			System.out.print("Enter the amount to be withdrawn : ");
			amount=sc.nextBigDecimal();
			try 
			{
				customer=walletService.withdrawAmount(mobileNo, amount);
				System.out.println("Your have successfully withdrawn... ");
				System.out.println("Now Your Account Balance is "+customer.getWallet().getBalance());
			} 
			catch (InvalidInputException | InsufficientBalanceException e)
			{
				System.out.println(e.getMessage());				
			}

			break;

		case 6: System.out.println("Thank you for using Payment Wallet Application");
		System.exit(0);
		break;


		default: System.out.println("Please Enter a valid Option");
		break;
		}
	}
	public static void main( String[] args )
	{
		Client client=new Client();
		while(true)
			client.Operations();
	}
}
