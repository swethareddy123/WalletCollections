package com.cg.service;
import java.math.BigDecimal;

import com.cg.dto.Customer;


public interface WalletService {
	public Customer createAccount(String name ,String mobileno, BigDecimal amount);
	public Customer showBalance (String mobileno);
	public Customer fundTransfer (String sourceMobileNo,String targetMobileNo, BigDecimal amount);
	public Customer depositAmount (String mobileNo,BigDecimal amount );
	public Customer withdrawAmount(String mobileNo, BigDecimal amount);
	public boolean isValidName(String name);
	public boolean isValid(String mobileNo);
	public boolean isValidMobile(String mobileNo);
	public boolean isValidAmount(BigDecimal amount);

}
