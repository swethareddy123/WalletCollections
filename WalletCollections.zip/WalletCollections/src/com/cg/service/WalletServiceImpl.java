
package com.cg.service;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;






import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.dao.WalletDao;
import com.cg.dao.WalletDaoImpl;
import com.cg.dto.Customer;
import com.cg.dto.Wallet;
import com.cg.exception.InsufficientBalanceException;
import com.cg.exception.InvalidInputException;


public class WalletServiceImpl implements WalletService
{

	private WalletDao dao;


	public WalletServiceImpl(Map<String, Customer> data){
		dao= new WalletDaoImpl(data);
	}
	public WalletServiceImpl(WalletDao dao) 
	{
		super();
		this.dao = dao;
	}


	public WalletServiceImpl() 
	{
	}


	public Customer createAccount(String name, String mobileNo, BigDecimal amount) 
	{
		Customer customer=null;

		if(isValidName(name) && isValidMobile(mobileNo) && isValidamount(amount))
		{
			customer=new Customer(name,mobileNo,new Wallet(amount));
			if(dao.findOne(mobileNo) != null)
				throw new InvalidInputException("The account with mobile Number "+ mobileNo+" is already created");
			dao.save(customer);
		}

		return customer;		
	}

	public Customer showBalance(String mobileNo) throws InvalidInputException
	{
		Customer customer=null;
		if(isValidMobile(mobileNo))
		{
			customer=dao.findOne(mobileNo);
		}
		if(customer == null)
			throw new InvalidInputException("The mobile Number You Entered is Not having Payment Wallet Account");
		return customer;
	}

	public Customer fundTransfer(String sourceMobileNo, String targetMobileNo, BigDecimal amount) throws InsufficientBalanceException,InvalidInputException
	{
		Customer source=null;
		Customer target=null;
		if(isValidMobile(sourceMobileNo) && isValidMobile(targetMobileNo) && isValidamount(amount))
		{
			if(sourceMobileNo.equals(targetMobileNo))
				throw new  InvalidInputException("Enter Different Accounts to transfer Money");

			if(amount.compareTo(new BigDecimal(0)) == 0 )
				throw new InvalidInputException("Enter valid Amount to transfer");
			source=dao.findOne(sourceMobileNo);

			if(source == null)
				throw new InvalidInputException("There is No Payment wallet account for the Number "+sourceMobileNo);

			target=dao.findOne(targetMobileNo);

			if(target == null)
				throw new InvalidInputException("There is No Payment wallet account for the Number "+targetMobileNo);

			if(amount.compareTo(source.getWallet().getBalance()) > 0 )
				throw new InsufficientBalanceException("Insufficient Balance in the account "+sourceMobileNo);
			/*BigDecimal srcbalance=source.getWallet().getBalance().subtract(amount);
		BigDecimal tarbalance=target.getWallet().getBalance().add(amount);

		source.setWallet(new Wallet(srcbalance));
		target.setWallet(new Wallet(tarbalance));*/

			source=withdrawAmount(sourceMobileNo, amount);
			target=depositAmount(targetMobileNo, amount);
			dao.save(source);
			dao.save(target);
		}
		return source;
	}

	public Customer depositAmount(String mobileNo, BigDecimal amount) throws InvalidInputException
	{
		Customer customer=null;
		if(isValidMobile(mobileNo) && isValidamount(amount))
		{
			customer=dao.findOne(mobileNo);

			if(customer == null)
				throw new InvalidInputException("There is No Payment wallet account for the Number "+mobileNo);

			if(amount.equals(new BigDecimal(0)))
				throw new InvalidInputException("Enter Valid Amount to Withdraw");

			BigDecimal balance=customer.getWallet().getBalance().add(amount);
			customer.setWallet(new Wallet(balance));
			dao.save(customer);
		}

		return customer;
	}

	public Customer withdrawAmount(String mobileNo, BigDecimal amount) throws InsufficientBalanceException
	{
		Customer customer=null;
		if(isValidMobile(mobileNo) && isValidamount(amount))
		{
			if(amount.equals(new BigDecimal(0)))
				throw new InvalidInputException("Enter Valid Amount to Withdraw");

			customer=dao.findOne(mobileNo);

			if(customer == null)
				throw new InvalidInputException("There is No Payment wallet account for the Number "+mobileNo);

			if(amount.compareTo(customer.getWallet().getBalance()) > 0 )
				throw new InsufficientBalanceException("Insufficient Balance");

			BigDecimal balance=customer.getWallet().getBalance().subtract(amount);
			customer.setWallet(new Wallet(balance));
			dao.save(customer);
		}
		return customer;
	}

	public boolean isValidName(String name) throws InvalidInputException 
	{
		if( name == null)
			throw new InvalidInputException( "Sorry, Customer Name is null" );

		if( name.trim().isEmpty() )
			throw new InvalidInputException( "Sorry, customer Name is Empty" );
		Pattern p = Pattern.compile("[A-Z]{1}[a-z]{3,10}");
		Matcher m = p.matcher(name);
		if(m.matches()){
			return true;
		}
		else{
			throw new InvalidInputException("Enter Valid Name \n Name should start with Capital letter");
		}
		/*return true;*/
	}

	public boolean isValidMobile(String mobileNo)throws InvalidInputException
	{
		if( mobileNo == null ||  isPhoneNumberInvalid( mobileNo ))
			throw new InvalidInputException( "Sorry, Phone Number "+mobileNo+" is invalid"  );

		return true;
	}

	public boolean isValidamount(BigDecimal amount)throws InvalidInputException
	{
		if( amount == null || isAmountInvalid( amount ) )
			throw new InvalidInputException( "Amount is invalid" );

		return true;
	}

	public boolean isAmountInvalid(BigDecimal amount) 
	{

		if( amount.compareTo(new BigDecimal(0)) < 0) 
		{
			return true;
		}		
		else 
			return false;
	}

	public static boolean isPhoneNumberInvalid( String phoneNumber )
	{
		if(String.valueOf(phoneNumber).matches("[6-9][0-9]{9}")) 
		{
			return false;
		}		
		else 
			return true;
	}
	@Override
	public boolean isValid(String mobileNo) {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public boolean isValidAmount(BigDecimal amount) {
		// TODO Auto-generated method stub
		return false;
	}

}