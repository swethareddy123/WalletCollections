package com.cg.dao;

import com.cg.dto.Customer;

public interface WalletDao {

    public boolean save(Customer customer);
	
	public Customer findOne(String mobileNo);
}
